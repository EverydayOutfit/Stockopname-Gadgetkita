# GadgetKita Stock Management

Aplikasi stock sederhana yang bisa dijalankan langsung di Visual Studio Code tanpa server/database.

## Login
Username: Gadgetkita
Password: Gasspoll

## Fitur
- Login
- Dashboard ringkasan
- Input Stock In
- Input Stock Out
- Validasi Stock Out agar tidak melebihi stock tersedia
- Live Stock berdasarkan tanggal
- Filter kategori
- Search berdasarkan Varian/SKU
- Riwayat transaksi
- Hapus transaksi
- Export Live Stock ke CSV
- Data tersimpan di browser menggunakan localStorage

## Cara menjalankan
1. Extract ZIP.
2. Buka folder `GadgetKita_Stock_App` di Visual Studio Code.
3. Buka `index.html`.
4. Klik kanan -> Open with Live Server (jika extension Live Server tersedia), atau buka file `index.html` langsung di browser.
5. Login dengan:
   Username: Gadgetkita
   Password: Gasspoll

## Catatan
Data tersimpan di browser/perangkat yang digunakan. Jika cache/localStorage browser dihapus, data aplikasi ikut terhapus.
